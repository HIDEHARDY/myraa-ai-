import React from "react";
import { Sparkles, Cpu, Mic, Volume2, Wrench, Shield, X, Radio } from "lucide-react";

interface InfoModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const InfoModal: React.FC<InfoModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fade-in">
      <div className="relative w-full max-w-xl bg-[#0D0D1F] border border-indigo-500/40 rounded-3xl p-6 sm:p-8 shadow-[0_0_60px_rgba(79,70,229,0.25)] text-white font-sans max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-white/10">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-gradient-to-tr from-indigo-500 to-pink-500 flex items-center justify-center shadow-lg shadow-indigo-500/30">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-bold">Myraa Architecture</h3>
              <p className="text-xs text-indigo-300/60 font-mono">Real-Time Voice-to-Voice Neural Interface</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full hover:bg-white/10 text-white/50 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="space-y-6 text-sm text-indigo-100/80">
          <div className="flex gap-4">
            <div className="p-2.5 rounded-xl bg-indigo-500/10 border border-indigo-500/20 text-indigo-400 h-fit shrink-0">
              <Cpu className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white mb-1 font-mono">Gemini 3.1 Flash Live Preview</h4>
              <p className="text-xs leading-relaxed text-indigo-200/70">
                Operates exclusively in audio-to-audio modality via continuous WebSocket proxy. Zero text generation delay. Features human-like pacing, witty personality, natural interruptions, and emotional inflection.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="p-2.5 rounded-xl bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 h-fit shrink-0">
              <Mic className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white mb-1 font-mono">PCM16 16kHz Stream & Equalizer</h4>
              <p className="text-xs leading-relaxed text-indigo-200/70">
                Raw microphone audio is captured via Web Audio ScriptProcessor, encoded as Int16 Little-Endian PCM at 16,000Hz, and streamed in real time over TLS. Input RMS drives dynamic HUD ring scaling.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="p-2.5 rounded-xl bg-pink-500/10 border border-pink-500/20 text-pink-400 h-fit shrink-0">
              <Volume2 className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white mb-1 font-mono">Web Audio Gapless 24kHz Player</h4>
              <p className="text-xs leading-relaxed text-indigo-200/70">
                Incoming audio turn chunks are decoded to Float32 and scheduled gaplessly on a 24,000Hz AudioContext clock. Instant interruption cancellation clears audio queues on user speech cutoff.
              </p>
            </div>
          </div>

          <div className="flex gap-4">
            <div className="p-2.5 rounded-xl bg-amber-500/10 border border-amber-500/20 text-amber-400 h-fit shrink-0">
              <Wrench className="w-5 h-5" />
            </div>
            <div>
              <h4 className="font-bold text-white mb-1 font-mono">Autonomous Function Calling</h4>
              <p className="text-xs leading-relaxed text-indigo-200/70">
                Myraa autonomously triggers client tools: <span className="font-mono text-amber-300">openWebsite</span> (launches embedded web portal modals & new tabs), <span className="font-mono text-amber-300">changeUiColor</span> (modulates HUD glowing visual theme), <span className="font-mono text-amber-300">showHolographicCard</span> (renders weather/facts), and <span className="font-mono text-amber-300">triggerSpecialEffect</span> (particle confetti).
              </p>
            </div>
          </div>
        </div>

        <div className="mt-8 pt-4 border-t border-white/10 flex items-center justify-between text-xs font-mono text-indigo-300">
          <span className="flex items-center gap-1.5 text-emerald-400">
            <Radio className="w-4 h-4 animate-pulse" /> TLS SECURE LINK
          </span>
          <button
            onClick={onClose}
            className="px-6 py-2 bg-white/10 hover:bg-white/20 rounded-xl text-white font-bold transition-all"
          >
            Acknowledge
          </button>
        </div>
      </div>
    </div>
  );
};
