import React from "react";
import { GlowTheme, SessionStats } from "../types";
import { Search, Brain, Zap, MessageSquareHeart } from "lucide-react";

interface SideIndicatorsProps {
  stats: SessionStats;
  theme: GlowTheme;
}

export const SideIndicators: React.FC<SideIndicatorsProps> = ({ stats, theme }) => {
  return (
    <>
      {/* Left HUD Panel */}
      <div className="hidden xl:flex absolute left-8 lg:left-12 top-1/2 -translate-y-1/2 flex-col gap-4 z-10 select-none pointer-events-none">
        <div className="group bg-white/5 backdrop-blur-xl p-4 rounded-2xl border border-white/10 w-52 transition-all hover:bg-white/10 pointer-events-auto shadow-lg">
          <div className="flex items-center gap-2 mb-2">
            <Search className="w-3.5 h-3.5 text-indigo-400" />
            <p className="text-[10px] uppercase tracking-widest text-indigo-400 font-bold">Web Search Tool</p>
          </div>
          <p className="text-xs text-indigo-100/70 font-sans">Ready to launch browser portals & fetch live links</p>
        </div>

        <div className="group bg-white/5 backdrop-blur-xl p-4 rounded-2xl border border-pink-500/30 w-52 shadow-[0_0_20px_rgba(236,72,153,0.1)] pointer-events-auto">
          <div className="flex items-center gap-2 mb-2">
            <Brain className="w-3.5 h-3.5 text-pink-400" />
            <p className="text-[10px] uppercase tracking-widest text-pink-400 font-bold">Context Memory</p>
          </div>
          <p className="text-xs text-pink-100/70 font-sans">Continuous audio session stream retention active</p>
        </div>
      </div>

      {/* Right HUD Panel */}
      <div className="hidden xl:flex absolute right-8 lg:right-12 top-1/2 -translate-y-1/2 flex-col gap-4 z-10 select-none pointer-events-none">
        <div className="bg-white/5 backdrop-blur-xl border border-white/10 rounded-3xl p-6 w-56 space-y-5 pointer-events-auto shadow-lg">
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-[10px] uppercase tracking-widest text-indigo-400 font-bold flex items-center gap-1.5">
                <Zap className="w-3 h-3" /> Latency Score
              </span>
              <span className="text-[10px] font-mono text-emerald-400 font-bold">{stats.latencyMs}ms</span>
            </div>
            
            {/* Visual Equalizer Bars representing low latency */}
            <div className="flex items-end gap-1.5 h-8">
              <div className="w-2 bg-indigo-500/40 h-3 rounded-sm transition-all duration-300" style={{ height: `${25 + stats.outputVolume * 60}%` }} />
              <div className="w-2 bg-indigo-500/60 h-5 rounded-sm transition-all duration-300" style={{ height: `${40 + stats.inputVolume * 50}%` }} />
              <div className="w-2 bg-indigo-500 h-8 rounded-sm animate-pulse" />
              <div className="w-2 bg-indigo-500/60 h-4 rounded-sm transition-all duration-300" style={{ height: `${30 + stats.outputVolume * 40}%` }} />
              <div className="w-2 bg-indigo-500/40 h-6 rounded-sm transition-all duration-300" style={{ height: `${50 + stats.inputVolume * 30}%` }} />
            </div>
            <p className="text-[10px] mt-2 text-white/40 font-mono">Ultra-Low Latency PCM16</p>
          </div>

          <div className="h-[1px] bg-white/10 w-full" />

          <div>
            <p className="text-[10px] uppercase tracking-widest text-pink-400 font-bold mb-2 flex items-center gap-1.5">
              <MessageSquareHeart className="w-3 h-3" /> Voice Tone
            </p>
            <span className="text-xs px-3 py-1 bg-pink-500/20 text-pink-300 rounded-full border border-pink-500/30 font-medium inline-block shadow-sm">
              Playful, Witty & Warm
            </span>
          </div>
        </div>
      </div>
    </>
  );
};
