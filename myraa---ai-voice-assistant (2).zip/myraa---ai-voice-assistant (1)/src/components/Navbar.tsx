import React from "react";
import { AssistantState, GlowTheme } from "../types";
import { Volume2, VolumeX, Sparkles, Radio, ShieldCheck } from "lucide-react";

interface NavbarProps {
  state: AssistantState;
  theme: GlowTheme;
  isMuted: boolean;
  onToggleMute: () => void;
  onOpenInfo: () => void;
  onOpenMemoryStorage: () => void;
}

const themeGradients: Record<GlowTheme, string> = {
  cyan: "from-cyan-500 to-blue-600",
  emerald: "from-emerald-400 to-teal-600",
  magenta: "from-indigo-500 to-pink-500",
  amber: "from-amber-400 to-orange-600",
  violet: "from-violet-500 to-purple-600",
  crimson: "from-rose-500 to-red-600"
};

const themeText: Record<GlowTheme, string> = {
  cyan: "text-cyan-400",
  emerald: "text-emerald-400",
  magenta: "text-pink-400",
  amber: "text-amber-400",
  violet: "text-violet-400",
  crimson: "text-rose-400"
};

export const Navbar: React.FC<NavbarProps> = ({
  state,
  theme,
  isMuted,
  onToggleMute,
  onOpenInfo,
  onOpenMemoryStorage
}) => {
  const isOnline = state === "listening" || state === "speaking";
  const gradClass = themeGradients[theme] || themeGradients.magenta;
  const textClass = themeText[theme] || themeText.magenta;

  return (
    <nav className="flex justify-between items-center px-6 md:px-12 py-6 z-20 shrink-0">
      <div className="flex items-center gap-3">
        <div className={`w-10 h-10 bg-gradient-to-tr ${gradClass} rounded-xl flex items-center justify-center shadow-lg shadow-indigo-500/20 transition-all duration-500`}>
          <span className="text-white font-black text-xl tracking-tighter">M</span>
        </div>
        <div className="flex flex-col">
          <div className="flex items-center gap-2">
            <span className="text-2xl font-bold tracking-tight bg-clip-text text-transparent bg-gradient-to-r from-white via-indigo-100 to-indigo-300">
              Myraa
            </span>
            <span className="text-[10px] px-2 py-0.5 rounded-full bg-white/10 border border-white/15 text-indigo-200 font-mono font-semibold">
              v3.1-LIVE
            </span>
          </div>
          <span className="text-[10px] text-indigo-300/60 hidden sm:block tracking-wide">
            Real-Time Audio-to-Audio Neural Companion
          </span>
        </div>
      </div>

      <div className="flex items-center gap-3 md:gap-6">
        {/* Status indicator pill */}
        <div className="flex items-center gap-2 bg-white/5 backdrop-blur-md px-3 md:px-4 py-2 rounded-full border border-white/10 shadow-inner shrink-0">
          <div className={`w-2 h-2 rounded-full ${isOnline ? "bg-emerald-400 animate-pulse" : state === "connecting" ? "bg-amber-400 animate-ping" : "bg-rose-500/80"}`} />
          <span className={`text-[10px] md:text-xs font-semibold uppercase tracking-widest ${isOnline ? "text-emerald-400" : state === "connecting" ? "text-amber-400" : "text-white/40"}`}>
            {isOnline ? "Live Link Active" : state === "connecting" ? "Establishing" : "Standby"}
          </span>
        </div>

        {/* Audio Mute toggle */}
        {isOnline && (
          <button
            onClick={onToggleMute}
            title={isMuted ? "Unmute Myraa" : "Mute Myraa"}
            className={`w-10 h-10 rounded-full bg-white/5 border ${isMuted ? "border-rose-500/50 text-rose-400 bg-rose-500/10" : "border-white/10 text-indigo-300 hover:bg-white/10"} flex items-center justify-center transition-all`}
          >
            {isMuted ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>
        )}

        {/* Memory Storage button */}
        <button
          onClick={onOpenMemoryStorage}
          id="memory-storage-button"
          title="Open Neural Memory Vault"
          className="px-3.5 py-2 rounded-full bg-gradient-to-r from-indigo-600/40 via-purple-600/40 to-pink-600/40 hover:from-indigo-600/60 hover:to-pink-600/60 border border-indigo-500/50 flex items-center gap-2 text-xs font-bold text-white shadow-[0_0_15px_rgba(99,102,241,0.2)] hover:shadow-[0_0_25px_rgba(236,72,153,0.4)] transition-all cursor-pointer shrink-0"
        >
          <span className="text-sm">🧠</span>
          <span>Memory Storage</span>
        </button>

        {/* Info button */}
        <button
          onClick={onOpenInfo}
          title="Neural Architecture Info"
          className="w-10 h-10 rounded-full bg-white/5 border border-white/10 flex items-center justify-center hover:bg-white/10 transition-colors text-indigo-300"
        >
          <Sparkles className="w-5 h-5" />
        </button>
      </div>
    </nav>
  );
};
