import React from "react";
import { AssistantState, GlowTheme } from "../types";
import { ShieldCheck, Power, Radio, Disc } from "lucide-react";

interface WaveformFooterProps {
  state: AssistantState;
  theme: GlowTheme;
  inputVolume: number; // 0 to 1
  outputVolume: number; // 0 to 1
  sessionDurationSec: number;
  onDisconnect: () => void;
}

const themeBarColors: Record<GlowTheme, { high: string; mid: string; low: string; text: string }> = {
  cyan: { high: "bg-cyan-300", mid: "bg-cyan-500/70", low: "bg-cyan-500/30", text: "text-cyan-300" },
  emerald: { high: "bg-emerald-300", mid: "bg-emerald-500/70", low: "bg-emerald-500/30", text: "text-emerald-300" },
  magenta: { high: "bg-pink-400", mid: "bg-indigo-500/70", low: "bg-indigo-500/30", text: "text-indigo-300" },
  amber: { high: "bg-amber-300", mid: "bg-amber-500/70", low: "bg-amber-500/30", text: "text-amber-300" },
  violet: { high: "bg-fuchsia-300", mid: "bg-violet-500/70", low: "bg-violet-500/30", text: "text-violet-300" },
  crimson: { high: "bg-rose-300", mid: "bg-rose-500/70", low: "bg-rose-500/30", text: "text-rose-300" }
};

export const WaveformFooter: React.FC<WaveformFooterProps> = ({
  state,
  theme,
  inputVolume,
  outputVolume,
  sessionDurationSec,
  onDisconnect
}) => {
  const isOnline = state === "listening" || state === "speaking";
  const activeVol = state === "speaking" ? outputVolume : state === "listening" ? inputVolume : 0;
  const colors = themeBarColors[theme] || themeBarColors.magenta;

  // Format seconds to HH:MM:SS
  const formatTime = (secs: number) => {
    const h = Math.floor(secs / 3600).toString().padStart(2, "0");
    const m = Math.floor((secs % 3600) / 60).toString().padStart(2, "0");
    const s = (secs % 60).toString().padStart(2, "0");
    return `${h}:${m}:${s}`;
  };

  // Equalizer bar heights (Symmetric 15 bars)
  const baseHeights = [12, 24, 40, 65, 85, 110, 80, 100, 80, 110, 85, 65, 40, 24, 12];
  
  return (
    <footer className="w-full px-4 md:px-8 pb-3 md:pb-4 pt-2 flex flex-col justify-end z-20 shrink-0">
      {/* Symmetric Waveform Equalizer */}
      <div className="flex items-center justify-center gap-1 sm:gap-1.5 h-10 sm:h-12 mb-2 max-w-xl mx-auto w-full">
        {baseHeights.map((bh, idx) => {
          // Modulate height based on active PCM volume
          const multiplier = isOnline ? 0.35 + activeVol * 1.6 : 0.15;
          const dynamicH = Math.min(100, Math.max(10, bh * multiplier));
          
          let colorClass = colors.low;
          if (idx % 3 === 0) colorClass = colors.high;
          else if (idx % 2 === 0) colorClass = colors.mid;

          return (
            <div
              key={idx}
              className={`w-1 sm:w-1.5 rounded-full transition-all duration-100 ${isOnline ? colorClass : "bg-white/10"}`}
              style={{ height: `${dynamicH}%` }}
            />
          );
        })}
      </div>

      {/* Futuristic Controls Bar */}
      <div className="flex flex-col sm:flex-row justify-between items-center gap-2.5 bg-white/5 backdrop-blur-2xl border border-white/10 rounded-xl py-2 px-3 sm:px-4 shadow-xl">
        <div className="flex items-center gap-2.5">
          <div className="p-1.5 rounded-lg bg-white/5 border border-white/10 text-indigo-300">
            <Radio className={`w-4 h-4 ${isOnline ? "animate-pulse text-emerald-400" : "text-white/40"}`} />
          </div>
          <div className="flex flex-col">
            <span className="text-[11px] sm:text-xs text-indigo-200/80 font-mono font-bold tracking-wider">
              {isOnline ? "BIDIRECTIONAL AUDIO LIVE" : "STREAM STANDBY"}
            </span>
            <span className="text-[9px] text-white/30 font-mono hidden sm:block">
              PCM16 16kHz MIC // WEB AUDIO 24kHz OUT
            </span>
          </div>
        </div>

        <div className="flex items-center gap-4 sm:gap-6">
          <div className="flex flex-col items-center sm:items-end">
            <span className="text-[8px] font-bold text-white/40 uppercase tracking-widest font-mono">
              Session
            </span>
            <span className={`text-sm sm:text-base font-mono font-bold ${isOnline ? colors.text : "text-white/30"}`}>
              {formatTime(sessionDurationSec)}
            </span>
          </div>

          {isOnline ? (
            <button
              onClick={onDisconnect}
              className="px-3.5 py-1.5 bg-rose-500/15 border border-rose-500/30 text-rose-300 hover:text-white rounded-lg text-xs font-bold uppercase tracking-wider hover:bg-rose-500/30 transition-all shadow-md shadow-rose-500/10 flex items-center gap-1.5 active:scale-95 cursor-pointer"
            >
              <Power className="w-3.5 h-3.5" />
              <span>Disconnect</span>
            </button>
          ) : (
            <div className="px-3 py-1 bg-white/5 border border-white/10 text-white/40 rounded-lg text-xs font-mono">
              Offline
            </div>
          )}
        </div>
      </div>
    </footer>
  );
};
