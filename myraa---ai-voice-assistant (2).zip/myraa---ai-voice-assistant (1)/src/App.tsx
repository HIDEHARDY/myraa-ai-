import React, { useEffect, useRef, useState, useCallback } from "react";
import { AppState, StateManager } from "./modules/StateManager";
import { AudioStreamer } from "./modules/AudioStreamer";
import { AudioPlayer } from "./modules/AudioPlayer";
import { LiveSession } from "./modules/LiveSession";
import { ToolManager } from "./modules/ToolManager";
import { globalMemoryManager } from "./modules/MemoryManager";
import { AssistantState, GlowTheme, HolographicCardData, ToolExecutionNotification } from "./types";

import { Navbar } from "./components/Navbar";
import { SideIndicators } from "./components/SideIndicators";
import { CoreOrb } from "./components/CoreOrb";
import { WaveformFooter } from "./components/WaveformFooter";
import { WebPortalModal } from "./components/WebPortalModal";
import { InfoModal } from "./components/InfoModal";
import { MemoryStorageModal } from "./components/MemoryStorageModal";
import { Sparkles, Globe, Palette, PartyPopper, CloudSun, AlertTriangle, RefreshCw } from "lucide-react";

export default function App() {
  const stateManagerRef = useRef<StateManager>(new StateManager());
  const audioStreamerRef = useRef<AudioStreamer>(new AudioStreamer());
  const audioPlayerRef = useRef<AudioPlayer>(new AudioPlayer());
  const liveSessionRef = useRef<LiveSession | null>(null);
  const toolManagerRef = useRef<ToolManager | null>(null);

  const [uiState, setUiState] = useState<AppState>(stateManagerRef.current.getState());
  const [isInfoModalOpen, setIsInfoModalOpen] = useState(false);
  const [isMemoryModalOpen, setIsMemoryModalOpen] = useState(false);
  const [micError, setMicError] = useState<string | null>(null);

  const handleUpdateState = useCallback((partial: Partial<AppState>) => {
    stateManagerRef.current.setState(partial);
  }, []);

  // Sync state manager to React state
  useEffect(() => {
    const unsubscribe = stateManagerRef.current.subscribe((nextState) => {
      setUiState(nextState);
    });
    return unsubscribe;
  }, []);

  // Load persistent memories from server database on app startup
  useEffect(() => {
    globalMemoryManager.loadMemoriesFromServer().catch((err) => {
      console.error("Failed to load persistent memories from server:", err);
    });
  }, []);

  // Initialize ToolManager
  useEffect(() => {
    toolManagerRef.current = new ToolManager({
      onSetTheme: (theme: GlowTheme) => {
        stateManagerRef.current.setState({ theme });
      },
      onShowCard: (card: HolographicCardData) => {
        stateManagerRef.current.setState({ activeCard: card });
      },
      onOpenWeb: (url: string, title: string) => {
        stateManagerRef.current.setState({ activePortal: { url, title } });
      },
      onAddNotification: (notif: ToolExecutionNotification) => {
        stateManagerRef.current.addNotification(notif);
      },
      onUpdateOsState: (partialState: any) => {
        stateManagerRef.current.setState(partialState);
      },
      getOsState: () => {
        return stateManagerRef.current.getState();
      },
      onRequestApproval: (command: string, terminalType: string) => {
        return new Promise<boolean>((resolve) => {
          stateManagerRef.current.setState({
            terminalApprovalRequest: {
              command,
              terminalType,
              resolve: (approved: boolean) => {
                stateManagerRef.current.setState({ terminalApprovalRequest: null });
                resolve(approved);
              }
            }
          });
        });
      }
    });
  }, []);

  // Initialize LiveSession
  useEffect(() => {
    liveSessionRef.current = new LiveSession({
      onConnect: () => {
        stateManagerRef.current.setAssistantState("listening");
        stateManagerRef.current.setState({
          errorMessage: null,
          activeCard: {
            id: "connected_card",
            title: "Myraa Voice Companion Online",
            content: "Bidirectional PCM audio stream established. Speak naturally into your microphone or try asking Myraa to open a web portal, check weather, or change HUD theme.",
            category: "fact",
            timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })
          }
        });
      },
      onDisconnect: () => {
        stateManagerRef.current.setAssistantState("disconnected");
        audioStreamerRef.current.stop();
        audioPlayerRef.current.close();
      },
      onAudioOutput: (base64PCM: string) => {
        audioPlayerRef.current.playChunk(base64PCM);
        if (stateManagerRef.current.getState().assistantState !== "speaking") {
          stateManagerRef.current.setAssistantState("speaking");
        }
      },
      onInterrupted: () => {
        audioPlayerRef.current.interrupt();
        stateManagerRef.current.setAssistantState("listening");
      },
      onToolCalls: async (calls) => {
        if (toolManagerRef.current) {
          const responses = await toolManagerRef.current.executeToolCalls(calls);
          liveSessionRef.current?.sendToolResponses(responses);
        }
      },
      onError: (err) => {
        console.warn("Session Error:", err);
        stateManagerRef.current.setState({ errorMessage: err });
        stateManagerRef.current.setAssistantState("disconnected");
        audioStreamerRef.current.stop();
      }
    });

    return () => {
      liveSessionRef.current?.disconnect();
    };
  }, []);

  // Check when speaking finishes
  useEffect(() => {
    const checkPlayingInterval = setInterval(() => {
      const state = stateManagerRef.current.getState();
      if (state.assistantState === "speaking") {
        if (!audioPlayerRef.current.getIsPlaying()) {
          stateManagerRef.current.setAssistantState("listening");
        }
      }
    }, 200);

    return () => clearInterval(checkPlayingInterval);
  }, []);

  const handleConnect = useCallback(async () => {
    setMicError(null);
    stateManagerRef.current.setAssistantState("connecting");

    try {
      // Start microphone capturing
      await audioStreamerRef.current.start(
        (base64PCM) => {
          liveSessionRef.current?.sendAudioInput(base64PCM);
        },
        (inputVol) => {
          stateManagerRef.current.setState({ inputVolume: inputVol });
        }
      );

      // Initialize audio player
      audioPlayerRef.current.initialize((outputVol) => {
        stateManagerRef.current.setState({ outputVolume: outputVol });
      });

      // Connect websocket proxy
      liveSessionRef.current?.connect();
    } catch (err: any) {
      console.warn("Microphone or Connect Notice:", err);
      let errorMsg = err?.message || (typeof err === "string" ? err : "Could not access microphone.");
      const errStr = (err?.message || err?.name || String(err)).toLowerCase();
      if (errStr.includes("permission") || errStr.includes("notallowed") || errStr.includes("denied")) {
        errorMsg = "Microphone access was denied. If you are viewing inside AI Studio live preview, please click the 'Open in new tab' button at the top right of the preview window to grant microphone access, or allow microphone permission in your browser address bar.";
      }
      setMicError(errorMsg);
      stateManagerRef.current.setAssistantState("disconnected");
    }
  }, []);

  const handleDisconnect = useCallback(() => {
    liveSessionRef.current?.disconnect();
    audioStreamerRef.current.stop();
    audioPlayerRef.current.close();
    stateManagerRef.current.setAssistantState("disconnected");
  }, []);

  const handleTogglePower = useCallback(() => {
    if (uiState.assistantState === "disconnected") {
      handleConnect();
    } else if (uiState.assistantState === "listening" || uiState.assistantState === "speaking") {
      handleDisconnect();
    }
  }, [uiState.assistantState, handleConnect, handleDisconnect]);

  const handleToggleMute = useCallback(() => {
    const nextMute = !uiState.isMuted;
    audioPlayerRef.current.setMute(nextMute);
    stateManagerRef.current.setState({ isMuted: nextMute });
  }, [uiState.isMuted]);

  // Voice Prompt Helper Chips (simulates user speaking or prompts them what to say)
  const voiceHints = [
    { label: "Open Wikipedia", icon: <Globe className="w-3.5 h-3.5 text-cyan-400" />, prompt: "Open wikipedia.org for me" },
    { label: "Weather Report", icon: <CloudSun className="w-3.5 h-3.5 text-amber-400" />, prompt: "Show me a holographic card with a sci-fi weather report for Neo Tokyo" },
    { label: "Theme: Emerald", icon: <Palette className="w-3.5 h-3.5 text-emerald-400" />, prompt: "Change UI color theme to emerald" },
    { label: "Celebrate!", icon: <PartyPopper className="w-3.5 h-3.5 text-pink-400" />, prompt: "Trigger special celebration effect confetti!" }
  ];

  return (
    <div className="w-full h-screen bg-[#020205] text-[#E0E0FF] font-sans overflow-hidden flex flex-col relative select-none">
      {/* Vibrant Background Atmosphere Gradients */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        <div className="absolute top-[-10%] left-[-10%] w-[55%] h-[55%] bg-[#4F46E5] opacity-20 blur-[130px] rounded-full animate-pulse" />
        <div className="absolute bottom-[-10%] right-[-10%] w-[55%] h-[55%] bg-[#EC4899] opacity-15 blur-[130px] rounded-full" />
        <div className="absolute top-[30%] right-[20%] w-[40%] h-[40%] bg-[#06b6d4] opacity-10 blur-[140px] rounded-full" />
      </div>

      {/* Navbar */}
      <Navbar
        state={uiState.assistantState}
        theme={uiState.theme}
        isMuted={uiState.isMuted}
        onToggleMute={handleToggleMute}
        onOpenInfo={() => setIsInfoModalOpen(true)}
        onOpenMemoryStorage={() => setIsMemoryModalOpen(true)}
      />

      {/* Main AI Interaction Space */}
      <main className="flex-1 flex flex-col items-center justify-center relative z-10 px-4 md:px-12 overflow-y-auto">
        {/* Side Indicator HUD Panels */}
        <SideIndicators
          stats={{
            latencyMs: uiState.latencyMs,
            inputVolume: uiState.inputVolume,
            outputVolume: uiState.outputVolume,
            sessionDurationSec: uiState.sessionDurationSec
          }}
          theme={uiState.theme}
        />

        {/* Error / Permission Banner */}
        {(micError || uiState.errorMessage) && (
          <div className="w-full max-w-lg mb-6 p-4 rounded-2xl bg-rose-500/15 border border-rose-500/30 text-rose-200 flex items-start gap-3 animate-fade-in shadow-xl z-30">
            <AlertTriangle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
            <div className="flex-1 text-xs sm:text-sm">
              <p className="font-bold mb-1">Attention Required</p>
              <p className="text-rose-200/80 leading-relaxed">{micError || uiState.errorMessage}</p>
              <button
                onClick={handleConnect}
                className="mt-3 px-4 py-1.5 bg-rose-500 hover:bg-rose-600 text-white font-bold rounded-xl text-xs flex items-center gap-1.5 transition-colors shadow-md"
              >
                <RefreshCw className="w-3.5 h-3.5" />
                <span>Retry Connection</span>
              </button>
            </div>
          </div>
        )}

        {/* Central Core Microphone / Power Orb */}
        <CoreOrb
          state={uiState.assistantState}
          theme={uiState.theme}
          inputVolume={uiState.inputVolume}
          outputVolume={uiState.outputVolume}
          onTogglePower={handleTogglePower}
        />

        {/* Voice Trigger Helper Chips (Only displayed when connected to inspire conversation) */}
        {uiState.assistantState !== "disconnected" && uiState.assistantState !== "connecting" && (
          <div className="mt-4 mb-2 flex flex-wrap items-center justify-center gap-2 sm:gap-3 max-w-xl px-4 animate-fade-in">
            <span className="text-[10px] font-mono uppercase tracking-widest text-indigo-300/50 w-full text-center mb-1">
              Example Voice Commands (Or speak anything)
            </span>
            {voiceHints.map((hint, idx) => (
              <div
                key={idx}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/5 hover:bg-white/10 border border-white/10 text-xs text-indigo-100 transition-all cursor-default select-none shadow-sm"
              >
                {hint.icon}
                <span className="font-medium">{hint.label}</span>
              </div>
            ))}
          </div>
        )}

        {/* Recent Tool Execution Notification Ticker */}
        {uiState.notifications.length > 0 && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-2 px-4 py-1.5 rounded-full bg-indigo-950/60 border border-indigo-500/30 backdrop-blur-md text-[10px] text-indigo-200 font-mono animate-fade-in pointer-events-none">
            <Sparkles className="w-3 h-3 text-pink-400 animate-spin" />
            <span className="text-white font-bold">TOOL EXECUTED:</span>
            <span className="truncate max-w-[200px] sm:max-w-xs">{uiState.notifications[0].message}</span>
          </div>
        )}
      </main>

      {/* Bottom Waveform Equalizer & Controls Footer */}
      <WaveformFooter
        state={uiState.assistantState}
        theme={uiState.theme}
        inputVolume={uiState.inputVolume}
        outputVolume={uiState.outputVolume}
        sessionDurationSec={uiState.sessionDurationSec}
        onDisconnect={handleDisconnect}
      />

      {/* Embedded Web Portal Modal */}
      <WebPortalModal
        portal={uiState.activePortal}
        onClose={() => stateManagerRef.current.setState({ activePortal: null })}
      />

      {/* Architecture Info Modal */}
      <InfoModal
        isOpen={isInfoModalOpen}
        onClose={() => setIsInfoModalOpen(false)}
      />

      {/* Memory Storage Vault Modal */}
      <MemoryStorageModal
        isOpen={isMemoryModalOpen}
        onClose={() => setIsMemoryModalOpen(false)}
      />

      {/* Terminal execution preventative confirmation check */}
      {uiState.terminalApprovalRequest && (
        <div className="fixed inset-0 bg-[#020208]/90 backdrop-blur-md flex items-center justify-center z-50 animate-fade-in p-4">
          <div className="w-full max-w-md p-6 rounded-3xl bg-[#090915] border border-rose-500/30 shadow-[0_0_50px_rgba(239,68,68,0.15)] font-mono text-xs">
            <div className="flex items-center gap-2 mb-4 border-b border-white/5 pb-3">
              <span className="w-2 h-2 rounded-full bg-rose-500 animate-ping" />
              <h3 className="text-sm font-bold text-rose-400 tracking-wider">SECURITY ACCESS REQUIRED</h3>
            </div>
            
            <p className="text-indigo-200/80 mb-3 font-sans">
              Myraa is requesting user authorization to execute a controlled terminal command:
            </p>

            <div className="p-3 bg-black/60 border border-white/5 rounded-xl text-rose-300 font-mono text-[11px] break-all select-text mb-4">
              <span className="text-gray-400 mr-1.5 select-none">$</span>
              {uiState.terminalApprovalRequest.command}
            </div>

            <div className="flex justify-between items-center text-[10px] text-indigo-300/40 mb-5 font-mono">
              <span>SHELL: {uiState.terminalApprovalRequest.terminalType}</span>
              <span>PRIVILEGE: SECURE_SANDBOX</span>
            </div>

            <div className="flex gap-2 font-mono">
              <button 
                onClick={() => uiState.terminalApprovalRequest?.resolve(false)}
                className="flex-1 py-2.5 rounded-xl border border-white/10 hover:bg-white/5 text-indigo-200 hover:text-white font-bold transition-all"
              >
                DENY & BLOCK
              </button>
              <button 
                onClick={() => uiState.terminalApprovalRequest?.resolve(true)}
                className="flex-1 py-2.5 rounded-xl bg-rose-500 hover:bg-rose-600 text-white font-bold transition-all shadow-lg shadow-rose-500/20"
              >
                AUTHORIZE RUN
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
